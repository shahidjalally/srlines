=== WooCommerce WhatsApp Notifications ===
Contributors: srlines
Tags: woocommerce, whatsapp, meta, notifications, order confirmation
Requires at least: 6.6
Tested up to: 6.7
Requires PHP: 8.2
Stable tag: 2.0.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Send WhatsApp order notifications and process customer confirmations/cancellations via Meta API.

== Description ==

Send automated WhatsApp notifications to customers when they place orders and when orders are fulfilled. Customers can reply with "0" to confirm or "1" to cancel their order, and the order status is automatically updated in WooCommerce.

= Features =

* 🚀 Automatic WhatsApp notifications for new orders
* 📦 Order fulfillment/shipping notifications
* ✅ Customer order confirmation via WhatsApp (reply "0")
* ❌ Customer order cancellation via WhatsApp (reply "1")
* 🔄 Automatic order status update in WooCommerce
* 📊 Dashboard with notification statistics
* 📱 Customer response tracking
* 🔗 Simple webhook integration - just POST customer responses
* 🎯 HPOS (High-Performance Order Storage) compatible
* 🛡️ Secure and production-ready

= How It Works =

1. Customer places order in WooCommerce
2. Plugin sends WhatsApp message with order details
3. Customer replies with "0" (Confirm) or "1" (Cancel)
4. CRM POSTs response to webhook URL: `/wp-json/wc-notifications/v1/customer-response`
5. Plugin updates order status automatically

= Webhook Format =

Configure your CRM to POST to this URL:
`https://yoursite.com/wp-json/wc-notifications/v1/customer-response`

With JSON payload:
```json
{
    "message": "0",
    "from": "+923001234567",
    "msg_id": "wamid.1234567890"
}