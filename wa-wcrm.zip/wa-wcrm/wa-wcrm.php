<?php
/*
 * Plugin Name: WooCommerce WhatsApp Notifications
 * Plugin URI: https://crm.srlines.net
 * Description: Sends WhatsApp notifications for WooCommerce orders and fulfillments via a configurable CRM API with HPOS compatibility.
 * Version: 1.0.1
 * Author: SRLINES SOFTWARE HOUSE (SMC-PRIVATE) LIMITED
 * Author URI: https://srlines.net
 * Requires at least: 6.6
 * Requires PHP: 8.2
 * WC requires at least: 9.3
 * WC tested up to: 10.0.2
 * Text Domain: woocommerce-notifications
 * Domain Path: /languages
 * License: GPL-2.0+
 * License URI: http://www.gnu.org/licenses/gpl-2.0.txt
 */

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly
}

class WooCommerce_Notifications {
    private $logger;
    private $crm_api_url = 'https://crm.srlines.net/api/v1/send_templet';
    private $db_version = '1.0';
    private $option_name = 'wc_notifications_settings';
    private $log_file;

    public function __construct() {
        $this->log_file = plugin_dir_path(__FILE__) . 'logs/wc-notifications.log';
        $this->init_logger();
        $this->register_hooks();
    }

    private function init_logger() {
        $this->logger = new class {
            public function info($message, $context = []) {
                $log_entry = sprintf(
                    "[%s] INFO: %s %s\n",
                    gmdate('Y-m-d H:i:s'),
                    $message,
                    json_encode($context)
                );
                file_put_contents(
                    plugin_dir_path(__FILE__) . 'logs/wc-notifications.log',
                    $log_entry,
                    FILE_APPEND
                );
            }

            public function error($message, $context = []) {
                $log_entry = sprintf(
                    "[%s] ERROR: %s %s\n",
                    gmdate('Y-m-d H:i:s'),
                    $message,
                    json_encode($context)
                );
                file_put_contents(
                    plugin_dir_path(__FILE__) . 'logs/wc-notifications.log',
                    $log_entry,
                    FILE_APPEND
                );
            }

            public function warn($message, $context = []) {
                $log_entry = sprintf(
                    "[%s] WARN: %s %s\n",
                    gmdate('Y-m-d H:i:s'),
                    $message,
                    json_encode($context)
                );
                file_put_contents(
                    plugin_dir_path(__FILE__) . 'logs/wc-notifications.log',
                    $log_entry,
                    FILE_APPEND
                );
            }
        };
    }

    private function register_hooks() {
        add_action('before_woocommerce_init', [$this, 'declare_hpos_compatibility']);
        register_activation_hook(__FILE__, [$this, 'activate']);
        register_deactivation_hook(__FILE__, [$this, 'deactivate']);
        add_action('init', [$this, 'check_woocommerce']);
        add_action('admin_notices', [$this, 'check_theme_templates']);
        add_action('admin_menu', [$this, 'add_admin_menu']);
        add_action('admin_enqueue_scripts', [$this, 'enqueue_scripts']);
        add_action('admin_init', [$this, 'register_ajax_actions']);
        add_action('woocommerce_order_status_changed', [$this, 'handle_order_status_change'], 10, 4);
        add_action('woocommerce_order_status_completed', [$this, 'handle_fulfillment'], 10, 1);
        add_action('woocommerce_api_wc_notifications_webhook', [$this, 'handle_webhook']);
        add_action('wp_loaded', [$this, 'handle_oauth']);
    }

    public function declare_hpos_compatibility() {
        if (class_exists('\Automattic\WooCommerce\Utilities\FeaturesUtil')) {
            \Automattic\WooCommerce\Utilities\FeaturesUtil::declare_compatibility('custom_order_tables', __FILE__, true);
        }
    }

    public function activate() {
        global $wpdb;
        $table_name = $wpdb->prefix . 'wc_notifications';
        $charset_collate = $wpdb->get_charset_collate();

        $sql = "CREATE TABLE $table_name (
            id bigint(20) NOT NULL AUTO_INCREMENT,
            shop varchar(255) NOT NULL,
            order_id varchar(50) NOT NULL,
            customer_name varchar(255) DEFAULT '',
            phone varchar(20) DEFAULT '',
            tracking_url varchar(255) DEFAULT '',
            example_arr text DEFAULT '',
            status varchar(20) DEFAULT 'pending',
            created_at datetime DEFAULT CURRENT_TIMESTAMP,
            updated_at datetime DEFAULT CURRENT_TIMESTAMP,
            error text DEFAULT NULL,
            PRIMARY KEY (id),
            UNIQUE KEY shop_order (shop, order_id)
        ) $charset_collate;";

        require_once ABSPATH . 'wp-admin/includes/upgrade.php';
        dbDelta($sql);

        if (!get_option('wc_notifications_db_version')) {
            add_option('wc_notifications_db_version', $this->db_version);
        }

        $this->create_asset_files();
        $this->register_webhooks();
        $this->logger->info('Plugin activated', ['db_version' => $this->db_version]);
    }

    public function deactivate() {
        $this->unregister_webhooks();
        $this->logger->info('Plugin deactivated');
    }

    public function check_woocommerce() {
        if (!class_exists('WooCommerce') || !function_exists('WC')) {
            $this->logger->error('WooCommerce is not active or not fully loaded');
            if (is_admin()) {
                add_action('admin_notices', function () {
                    echo '<div class="error"><p>WooCommerce Notifications requires WooCommerce 9.3+ to be installed and active.</p></div>';
                });
            }
            return false;
        }

        $wc_version = WC()->version;
        if (version_compare($wc_version, '9.3', '<')) {
            $this->logger->error('WooCommerce version too old', ['version' => $wc_version]);
            if (is_admin()) {
                add_action('admin_notices', function () use ($wc_version) {
                    echo '<div class="error"><p>WooCommerce Notifications requires WooCommerce 9.3+ (detected: ' . esc_html($wc_version) . '). Please update WooCommerce.</p></div>';
                });
            }
            return false;
        }

        $this->logger->info('WooCommerce check passed', ['version' => $wc_version]);
        return true;
    }

    public function check_theme_templates() {
        if (!$this->check_woocommerce() || !is_admin() || !function_exists('wc_get_outdated_templates')) {
            return;
        }

        $theme = wp_get_theme();
        if (is_child_theme() || !$theme->parent()) {
            $outdated_templates = wc_get_outdated_templates();
            if (!empty($outdated_templates)) {
                $this->logger->warn('Outdated WooCommerce templates detected', ['theme' => $theme->get('Name')]);
                add_action('admin_notices', function () use ($theme, $outdated_templates) {
                    echo '<div class="notice notice-warning"><p>The theme "' . esc_html($theme->get('Name')) . '" has outdated WooCommerce templates: ' . implode(', ', array_keys($outdated_templates)) . '. Update the theme or use a child theme to avoid compatibility issues.</p></div>';
                });
            }
        }
    }

    private function create_asset_files() {
        $logs_dir = plugin_dir_path(__FILE__) . 'logs';
        if (!file_exists($logs_dir)) {
            mkdir($logs_dir, 0755, true);
        }

        $assets_dir = plugin_dir_path(__FILE__) . 'assets';
        if (!file_exists($assets_dir)) {
            mkdir($assets_dir, 0755, true);
        }

        $css_content = '
            #wc-notifications-settings-form .form-table th {
                width: 200px;
            }
            #wc-notifications-settings-form .button {
                margin-right: 10px;
            }
        ';
        file_put_contents($assets_dir . '/style.css', $css_content);

        $js_content = '
            jQuery(document).ready(function($) {
                $("#wc-notifications-settings-form").on("submit", function(e) {
                    e.preventDefault();
                    const data = {
                        action: "wc_notifications_save_settings",
                        nonce: wcNotifications.nonce,
                        crmApiKey: $("#crm_api_key").val(),
                        orderCreatedEnabled: $("#order_created_enabled").is(":checked"),
                        orderCreatedTemplate: $("#order_created_template").val(),
                        fulfillmentCreatedEnabled: $("#fulfillment_created_enabled").is(":checked"),
                        fulfillmentCreatedTemplate: $("#fulfillment_created_template").val(),
                        defaultPhone: $("#default_phone").val()
                    };
                    $.ajax({
                        url: wcNotifications.ajax_url,
                        method: "POST",
                        data: data,
                        success: function(response) {
                            if (response.success) {
                                alert("Settings saved successfully!");
                            } else {
                                console.error("Save settings error:", response);
                                alert("Error: " + (response.data?.message || "Failed to save settings"));
                            }
                        },
                        error: function(xhr, status, error) {
                            console.error("Save settings AJAX error:", xhr.responseText, status, error);
                            alert("Error: Failed to save settings. Check console for details.");
                        }
                    });
                });

                $("#test-api-key").on("click", function() {
                    const apiKey = $("#crm_api_key").val();
                    if (!apiKey) {
                        alert("Please enter an API key");
                        return;
                    }
                    $.ajax({
                        url: wcNotifications.ajax_url,
                        method: "POST",
                        data: {
                            action: "wc_notifications_test_api_key",
                            nonce: wcNotifications.nonce,
                            apiKey: apiKey
                        },
                        success: function(response) {
                            if (response.success) {
                                alert(response.data.message);
                            } else {
                                console.error("Test API key error:", response);
                                alert("Error: " + (response.data?.message || "Failed to test API key"));
                            }
                        },
                        error: function(xhr, status, error) {
                            console.error("Test API key AJAX error:", xhr.responseText, status, error);
                            alert("Error: Failed to test API key. Check console for details.");
                        }
                    });
                });
            });
        ';
        file_put_contents($assets_dir . '/script.js', $js_content);
    }

    private function register_webhooks() {
        if (!$this->check_woocommerce()) {
            return;
        }

        $webhook_topics = [
            'order.created' => 'wc_notifications_order_created',
            'order.updated' => 'wc_notifications_order_updated'
        ];

        foreach ($webhook_topics as $topic => $name) {
            $webhook = new WC_Webhook();
            $webhook->set_name($name);
            $webhook->set_topic($topic);
            $webhook->set_delivery_url(home_url('/wc-api/wc_notifications_webhook'));
            $webhook->set_secret(wp_generate_password(32, false));
            $webhook->set_status('active');
            $webhook->save();
            $this->logger->info('Webhook registered', ['topic' => $topic, 'name' => $name]);
        }
    }

    private function unregister_webhooks() {
        if (!$this->check_woocommerce()) {
            $this->logger->warn('WooCommerce not active, skipping webhook unregistration');
            return;
        }

        if (function_exists('wc_get_webhooks')) {
            $webhooks = wc_get_webhooks();
            foreach ($webhooks as $webhook) {
                if (strpos($webhook->get_name(), 'wc_notifications_') === 0) {
                    $webhook->delete();
                    $this->logger->info('Webhook unregistered', ['name' => $webhook->get_name()]);
                }
            }
        } else {
            $this->logger->warn('wc_get_webhooks not available, cannot unregister webhooks');
        }
    }

    public function add_admin_menu() {
        add_menu_page(
            'WC Notifications',
            'WC Notifications',
            'manage_woocommerce',
            'wc-notifications',
            [$this, 'render_dashboard'],
            'dashicons-whatsapp',
            56
        );
        add_submenu_page(
            'wc-notifications',
            'Settings',
            'Settings',
            'manage_woocommerce',
            'wc-notifications-settings',
            [$this, 'render_settings']
        );
    }

    public function enqueue_scripts($hook) {
        if (strpos($hook, 'wc-notifications') === false) {
            return;
        }
        wp_enqueue_style(
            'wc-notifications-style',
            plugins_url('assets/style.css', __FILE__),
            [],
            '1.1.0'
        );
        wp_enqueue_script(
            'wc-notifications-script',
            plugins_url('assets/script.js', __FILE__),
            ['jquery'],
            '1.1.0',
            true
        );
        wp_localize_script('wc-notifications-script', 'wcNotifications', [
            'ajax_url' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('wc_notifications_nonce')
        ]);
    }

    public function render_dashboard() {
        ?>
        <div class="wrap">
            <h1>WooCommerce WhatsApp Notifications</h1>
            <p>Welcome to the WooCommerce Notifications dashboard.</p>
            <p>Configure your settings to enable WhatsApp notifications for orders and fulfillments.</p>
        </div>
        <?php
    }

    public function render_settings() {
        $settings = get_option($this->option_name, []);
        $crm_api_key = $settings['notificationSettings']['crmApiKey'] ?? '';
        ?>
        <div class="wrap">
            <h1>Notification Settings</h1>
            <form id="wc-notifications-settings-form">
                <table class="form-table">
                    <tr>
                        <th><label for="crm_api_key">CRM API Key</label></th>
                        <td><input type="text" id="crm_api_key" name="crm_api_key" value="<?php echo esc_attr($crm_api_key); ?>" class="regular-text" /></td>
                    </tr>
                    <tr>
                        <th><label for="order_created_enabled">Order Created Notifications</label></th>
                        <td><input type="checkbox" id="order_created_enabled" name="order_created_enabled" <?php checked($settings['notificationSettings']['orderCreated']['enabled'] ?? false); ?> /></td>
                    </tr>
                    <tr>
                        <th><label for="order_created_template">Order Created Template</label></th>
                        <td><input type="text" id="order_created_template" name="order_created_template" value="<?php echo esc_attr($settings['notificationSettings']['orderCreated']['templateName'] ?? ''); ?>" class="regular-text" /></td>
                    </tr>
                    <tr>
                        <th><label for="fulfillment_created_enabled">Fulfillment Created Notifications</label></th>
                        <td><input type="checkbox" id="fulfillment_created_enabled" name="fulfillment_created_enabled" <?php checked($settings['notificationSettings']['fulfillmentCreated']['enabled'] ?? false); ?> /></td>
                    </tr>
                    <tr>
                        <th><label for="fulfillment_created_template">Fulfillment Created Template</label></th>
                        <td><input type="text" id="fulfillment_created_template" name="fulfillment_created_template" value="<?php echo esc_attr($settings['notificationSettings']['fulfillmentCreated']['templateName'] ?? ''); ?>" class="regular-text" /></td>
                    </tr>
                    <tr>
                        <th><label for="default_phone">Default Phone Number</label></th>
                        <td><input type="text" id="default_phone" name="default_phone" value="<?php echo esc_attr($settings['notificationSettings']['defaultPhone'] ?? '+923339776136'); ?>" class="regular-text" /></td>
                    </tr>
                </table>
                <p class="submit">
                    <button type="submit" class="button button-primary">Save Settings</button>
                    <button type="button" id="test-api-key" class="button">Test API Key</button>
                </p>
            </form>
        </div>
        <?php
    }

    public function register_ajax_actions() {
        add_action('wp_ajax_wc_notifications_save_settings', [$this, 'ajax_save_settings']);
        add_action('wp_ajax_wc_notifications_test_api_key', [$this, 'ajax_test_api_key']);
    }

    public function ajax_save_settings() {
        check_ajax_referer('wc_notifications_nonce', 'nonce');
        if (!current_user_can('manage_woocommerce')) {
            wp_send_json_error(['message' => 'Insufficient permissions'], 403);
            return;
        }

        $crm_api_key = sanitize_text_field($_POST['crmApiKey'] ?? '');
        $order_created_enabled = boolval($_POST['orderCreatedEnabled'] ?? false);
        $order_created_template = sanitize_text_field($_POST['orderCreatedTemplate'] ?? '');
        $fulfillment_created_enabled = boolval($_POST['fulfillmentCreatedEnabled'] ?? false);
        $fulfillment_created_template = sanitize_text_field($_POST['fulfillmentCreatedTemplate'] ?? '');
        $default_phone = sanitize_text_field($_POST['defaultPhone'] ?? '+923339776136');

        if (empty($crm_api_key)) {
            $this->logger->error('CRM API key is required', ['shop' => home_url()]);
            wp_send_json_error(['message' => 'CRM API key is required'], 400);
            return;
        }

        try {
            $response = wp_remote_get("https://crm.srlines.net/api/v1/test?token=$crm_api_key", [
                'headers' => ['Authorization' => "Bearer $crm_api_key"],
                'timeout' => 10
            ]);
            if (is_wp_error($response) || !isset($response['body']) || !json_decode($response['body'])->success) {
                $this->logger->error('Invalid CRM API key', ['shop' => home_url()]);
                wp_send_json_error(['message' => 'Invalid CRM API key'], 400);
                return;
            }
        } catch (Exception $e) {
            $this->logger->error('Error testing API key', [
                'error' => $e->getMessage(),
                'shop' => home_url()
            ]);
            wp_send_json_error(['message' => 'Error testing API key'], 500);
            return;
        }

        $settings = [
            'notificationSettings' => [
                'crmApiKey' => $crm_api_key,
                'orderCreated' => [
                    'enabled' => $order_created_enabled,
                    'templateName' => $order_created_template
                ],
                'fulfillmentCreated' => [
                    'enabled' => $fulfillment_created_enabled,
                    'templateName' => $fulfillment_created_template
                ],
                'defaultPhone' => $default_phone
            ],
            'updatedAt' => current_time('mysql')
        ];

        update_option($this->option_name, $settings);
        $this->logger->info('Settings saved via AJAX', [
            'shop' => home_url(),
            'crmApiKey' => '[REDACTED]'
        ]);
        wp_send_json_success(['message' => 'Settings saved successfully']);
    }

    public function ajax_test_api_key() {
        check_ajax_referer('wc_notifications_nonce', 'nonce');
        if (!current_user_can('manage_woocommerce')) {
            wp_send_json_error(['message' => 'Insufficient permissions'], 403);
            return;
        }

        $api_key = sanitize_text_field($_POST['apiKey'] ?? '');
        if (empty($api_key)) {
            $this->logger->error('API key required', ['shop' => home_url()]);
            wp_send_json_error(['message' => 'API key required'], 400);
            return;
        }

        try {
            $response = wp_remote_get("https://crm.srlines.net/api/v1/test?token=$api_key", [
                'headers' => ['Authorization' => "Bearer $api_key"],
                'timeout' => 10
            ]);
            if (is_wp_error($response)) {
                $this->logger->error('API key test failed', [
                    'error' => $response->get_error_message(),
                    'shop' => home_url()
                ]);
                wp_send_json_error(['message' => 'API key test failed'], 400);
                return;
            }
            $body = json_decode($response['body']);
            if ($body->success) {
                $this->logger->info('API key test successful', ['shop' => home_url()]);
                wp_send_json_success(['message' => 'API key is valid']);
            } else {
                $this->logger->warn('API key test failed', ['shop' => home_url()]);
                wp_send_json_error(['message' => 'Invalid API key'], 400);
            }
        } catch (Exception $e) {
            $this->logger->error('Error testing API key', [
                'error' => $e->getMessage(),
                'shop' => home_url()
            ]);
            wp_send_json_error(['message' => 'Error testing API key'], 500);
        }
    }

    public function handle_order_status_change($order_id, $status_from, $status_to, $order) {
        if ($status_to === 'processing' && $order instanceof WC_Order) {
            $this->process_order_event($order_id, 'orderCreated', $order);
        }
    }

    public function handle_fulfillment($order_id) {
        $order = wc_get_order($order_id);
        if ($order instanceof WC_Order) {
            $this->process_order_event($order_id, 'fulfillmentCreated', $order);
        }
    }

    public function handle_webhook() {
        $webhook_data = file_get_contents('php://input');
        $data = json_decode($webhook_data, true);
        $order_id = $data['id'] ?? null;
        $topic = $_SERVER['HTTP_X_WC_WEBHOOK_TOPIC'] ?? '';

        if (!$order_id || !$topic) {
            $this->logger->error('Invalid webhook data', [
                'order_id' => $order_id,
                'topic' => $topic
            ]);
            wp_die('Invalid webhook data', '', ['response' => 400]);
        }

        $event_type = $topic === 'order.created' ? 'orderCreated' : ($topic === 'order.updated' && $data['status'] === 'completed' ? 'fulfillmentCreated' : null);
        if ($event_type) {
            $order = wc_get_order($order_id);
            if ($order instanceof WC_Order) {
                $this->process_order_event($order_id, $event_type, $order);
            }
        }

        wp_die('', '', ['response' => 200]);
    }

    private function process_order_event($order_id, $event_type, $order) {
        if (!$this->check_woocommerce()) {
            $this->logger->error('WooCommerce not active, cannot process event', ['order_id' => $order_id, 'event_type' => $event_type]);
            return;
        }

        $settings = get_option($this->option_name, []);
        if (!isset($settings['notificationSettings'][$event_type]['enabled']) || !$settings['notificationSettings'][$event_type]['enabled']) {
            $this->logger->info("{$event_type} notifications disabled", ['order_id' => $order_id]);
            return;
        }

        if (!$order) {
            $this->logger->error('Order not found', ['order_id' => $order_id]);
            return;
        }

        $customer = $order->get_user() ?: new stdClass();
        $phone = $order->get_billing_phone() ?: ($settings['notificationSettings']['defaultPhone'] ?? '+923339776136');
        $customer_name = $order->get_billing_first_name() ?: 'Customer';
        $order_name = $order->get_order_number();

        $example_arr = [
            $customer_name,
            $order_name
        ];

        global $wpdb;
        $table_name = $wpdb->prefix . 'wc_notifications';
        $shop = home_url();

        $notification_data = [
            'shop' => $shop,
            'order_id' => $order_name,
            'customer_name' => $customer_name,
            'phone' => $phone,
            'tracking_url' => '',
            'example_arr' => json_encode($example_arr),
            'status' => 'pending',
            'created_at' => current_time('mysql'),
            'updated_at' => current_time('mysql')
        ];

        $result = $wpdb->insert($table_name, $notification_data, [
            '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s'
        ]);

        if ($result === false) {
            if ($wpdb->last_error && strpos($wpdb->last_error, 'Duplicate entry') !== false) {
                $this->logger->warn('Duplicate notification, updating existing', [
                    'order_id' => $order_name,
                    'shop' => $shop
                ]);
                $wpdb->update(
                    $table_name,
                    [
                        'phone' => $phone,
                        'tracking_url' => '',
                        'status' => 'pending',
                        'updated_at' => current_time('mysql')
                    ],
                    ['shop' => $shop, 'order_id' => $order_name],
                    ['%s', '%s', '%s', '%s'],
                    ['%s', '%s']
                );
                $notification = $wpdb->get_row($wpdb->prepare("SELECT * FROM $table_name WHERE shop = %s AND order_id = %s", $shop, $order_name));
                $notification_id = $notification->id;
            } else {
                $this->logger->error('Failed to save notification', [
                    'error' => $wpdb->last_error,
                    'order_id' => $order_name
                ]);
                return;
            }
        } else {
            $notification_id = $wpdb->insert_id;
        }

        $this->send_notification(
            $notification_id,
            $shop,
            $event_type,
            $settings['notificationSettings'][$event_type]['templateName'],
            $example_arr,
            $phone
        );
    }

    private function send_notification($notification_id, $shop, $event_type, $template_name, $example_arr, $phone) {
        global $wpdb;
        $table_name = $wpdb->prefix . 'wc_notifications';
        $settings = get_option($this->option_name, []);

        if (empty($settings['notificationSettings']['crmApiKey'])) {
            $this->logger->error('CRM API key not configured', ['shop' => $shop]);
            $wpdb->update(
                $table_name,
                ['status' => 'failed', 'error' => 'CRM API key not configured', 'updated_at' => current_time('mysql')],
                ['id' => $notification_id],
                ['%s', '%s', '%s'],
                ['%d']
            );
            return;
        }

        $crm_api_key = $settings['notificationSettings']['crmApiKey'];

        try {
            $response = wp_remote_post($this->crm_api_url, [
                'headers' => [
                    'Content-Type' => 'application/json',
                    'Authorization' => "Bearer $crm_api_key"
                ],
                'body' => json_encode([
                    'sendTo' => $phone,
                    'templetName' => $template_name,
                    'exampleArr' => $example_arr,
                    'token' => $crm_api_key,
                    'mediaUri' => ''
                ]),
                'timeout' => 10
            ]);

            if (is_wp_error($response)) {
                throw new Exception($response->get_error_message());
            }

            $wpdb->update(
                $table_name,
                ['status' => 'sent', 'updated_at' => current_time('mysql')],
                ['id' => $notification_id],
                ['%s', '%s'],
                ['%d']
            );
            $this->logger->info('Notification sent', [
                'notification_id' => $notification_id,
                'shop' => $shop,
                'order_id' => $example_arr[1]
            ]);
        } catch (Exception $e) {
            $wpdb->update(
                $table_name,
                ['status' => 'failed', 'error' => $e->getMessage(), 'updated_at' => current_time('mysql')],
                ['id' => $notification_id],
                ['%s', '%s', '%s'],
                ['%d']
            );
            $this->logger->error('Error sending notification', [
                'notification_id' => $notification_id,
                'error' => $e->getMessage(),
                'shop' => $shop
            ]);
        }
    }

    public function handle_oauth() {
        if (!isset($_GET['wc_notifications_oauth'])) {
            return;
        }

        if (!$this->check_woocommerce()) {
            $this->logger->error('WooCommerce not active, cannot initiate OAuth');
            wp_die('WooCommerce is required for OAuth authentication');
        }

        $action = $_GET['wc_notifications_oauth'];
        $shop = home_url();
        $state = wp_generate_password(16, false);

        if ($action === 'start') {
            $consumer_key = 'ck_' . wp_generate_password(32, false);
            $consumer_secret = 'cs_' . wp_generate_password(32, false);

            global $wpdb;
            $wpdb->insert($wpdb->prefix . 'woocommerce_api_keys', [
                'user_id' => get_current_user_id(),
                'description' => 'WC Notifications OAuth',
                'permissions' => 'read_write',
                'consumer_key' => wc_api_hash($consumer_key),
                'consumer_secret' => $consumer_secret,
                'truncated_key' => substr($consumer_key, -7),
                'last_access' => null
            ]);

            $redirect_uri = add_query_arg(['wc_notifications_oauth' => 'callback', 'state' => $state], home_url());
            $auth_url = add_query_arg([
                'consumer_key' => $consumer_key,
                'app_name' => 'WC Notifications',
                'scope' => 'read_write',
                'user_id' => get_current_user_id(),
                'return_url' => $redirect_uri,
                'callback_url' => $redirect_uri
            ], home_url('/wc-api/auth'));

            set_transient('wc_notifications_oauth_state_' . $state, $consumer_key . '|' . $consumer_secret, 3600);
            $this->logger->info('Initiating OAuth', ['shop' => $shop, 'auth_url' => $auth_url]);
            wp_redirect($auth_url);
            exit;
        }

        if ($action === 'callback') {
            $state = $_GET['state'] ?? '';
            $stored_state = get_transient('wc_notifications_oauth_state_' . $state);
            if (!$stored_state) {
                $this->logger->error('Invalid OAuth state', ['shop' => $shop]);
                wp_die('Authentication failed: Invalid state');
            }

            list($consumer_key, $consumer_secret) = explode('|', $stored_state);
            update_option('wc_notifications_api_credentials', [
                'consumer_key' => $consumer_key,
                'consumer_secret' => $consumer_secret
            ]);
            delete_transient('wc_notifications_oauth_state_' . $state);

            $this->logger->info('OAuth completed', ['shop' => $shop]);
            wp_redirect(admin_url('admin.php?page=wc-notifications'));
            exit;
        }
    }
}

new WooCommerce_Notifications();
?>