
            jQuery(document).ready(function($) {
                $("#wc-notifications-settings-form").on("submit", function(e) {
                    e.preventDefault();
                    const data = {
                        action: "wc_notifications_save_settings",
                        nonce: wcNotifications.nonce,
                        crmApiKey: $("#crm_api_key").val(),
                        orderCreatedEnabled: $("#order_created_enabled").is(":checked"),
                        orderCreatedTemplate: $("#order_created_template").val(),
                        fulfillmentCreatedEnabled: $("#fulfillment_created_enabled").is(":checked"),
                        fulfillmentCreatedTemplate: $("#fulfillment_created_template").val(),
                        defaultPhone: $("#default_phone").val()
                    };
                    $.ajax({
                        url: wcNotifications.ajax_url,
                        method: "POST",
                        data: data,
                        success: function(response) {
                            if (response.success) {
                                alert("Settings saved successfully!");
                            } else {
                                console.error("Save settings error:", response);
                                alert("Error: " + (response.data?.message || "Failed to save settings"));
                            }
                        },
                        error: function(xhr, status, error) {
                            console.error("Save settings AJAX error:", xhr.responseText, status, error);
                            alert("Error: Failed to save settings. Check console for details.");
                        }
                    });
                });

                $("#test-api-key").on("click", function() {
                    const apiKey = $("#crm_api_key").val();
                    if (!apiKey) {
                        alert("Please enter an API key");
                        return;
                    }
                    $.ajax({
                        url: wcNotifications.ajax_url,
                        method: "POST",
                        data: {
                            action: "wc_notifications_test_api_key",
                            nonce: wcNotifications.nonce,
                            apiKey: apiKey
                        },
                        success: function(response) {
                            if (response.success) {
                                alert(response.data.message);
                            } else {
                                console.error("Test API key error:", response);
                                alert("Error: " + (response.data?.message || "Failed to test API key"));
                            }
                        },
                        error: function(xhr, status, error) {
                            console.error("Test API key AJAX error:", xhr.responseText, status, error);
                            alert("Error: Failed to test API key. Check console for details.");
                        }
                    });
                });
            });
        