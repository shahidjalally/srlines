=== WooCommerce WhatsApp Notifications ===
Contributors: srlines
Tags: woocommerce, whatsapp, notifications, crm, e-commerce
Requires at least: 6.6
Tested up to: 6.7
Stable tag: 1.0.1
Requires PHP: 8.2
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.txt

Sends WhatsApp notifications for WooCommerce orders and fulfillments via a configurable CRM API with HPOS compatibility.

== Description ==

This plugin enables WooCommerce store owners to send WhatsApp notifications to customers for order creation and fulfillment events using a third-party CRM API. It is compatible with WooCommerce High-Performance Order Storage (HPOS) and includes a user-friendly settings interface.

**Features:**
- Sends WhatsApp notifications for new orders and fulfillments.
- Configurable CRM API integration.
- Supports WooCommerce HPOS.
- Admin dashboard for easy configuration.
- Logging for debugging and monitoring.

**Privacy Notice:**
This plugin sends customer data (e.g., name, phone number) to a third-party CRM API for sending WhatsApp notifications. Store owners must ensure compliance with GDPR/CCPA by informing users and obtaining consent.

== Installation ==

1. Upload the plugin files to the `/wp-content/plugins/woocommerce-whatsapp-notifications` directory, or install the plugin through the WordPress plugins screen directly.
2. Activate the plugin through the 'Plugins' screen in WordPress.
3. Navigate to WooCommerce > WC Notifications > Settings to configure the CRM API URL, API key, and notification settings.
4. Test the API key to ensure connectivity.
5. Enable notifications and set templates as needed.

== Frequently Asked Questions ==

= What is the CRM API URL? =
The CRM API URL is the endpoint provided by your WhatsApp notification service provider. Contact your provider for details.

= Is this plugin GDPR/CCPA compliant? =
The plugin sends customer data to a third-party CRM API. You must inform users and obtain consent to comply with GDPR/CCPA regulations.

= Does this plugin support WooCommerce HPOS? =
Yes, the plugin is fully compatible with WooCommerce High-Performance Order Storage.

== Screenshots ==

1. Settings page for configuring notifications.
2. Dashboard overview.

== Changelog ==

= 1.0.1 =
* Added configurable CRM API URL.
* Improved security with proper sanitization and escaping.
* Added internationalization support.
* Added privacy notice for GDPR/CCPA compliance.
* Used WP_Filesystem for file operations.

= 1.0.0 =
* Initial release.

== Upgrade Notice ==

= 1.0.1 =
This update includes security improvements, internationalization, and a configurable CRM API URL. Please update your settings after upgrading.